# Portfolio — GitHub Pages untuk Taopik Hidayat

Situs portfolio statis siap dideploy ke domain **Taopik30.github.io**.

## Langkah Cepat (tanpa terminal)
1. Login GitHub: https://github.com/Taopik30
2. Buat repository **Taopik30.github.io** (harus sama persis dengan username).
3. Upload file **index.html** ke root repo.
4. Buka **Settings → Pages**, pilih:
   - **Source**: Deploy from a branch
   - **Branch**: `main` (root)
5. Akses: **https://Taopik30.github.io/** (tunggu ±1–3 menit).

## Langkah via terminal
```bash
git init
git add index.html
git commit -m "Init portfolio"
git branch -M main
git remote add origin https://github.com/Taopik30/Taopik30.github.io.git
git push -u origin main
```
Lalu aktifkan Pages (Settings → Pages) seperti di atas.

## Kustomisasi
- Edit teks/nama/email/link sosial di bagian **HERO** & **CONTACT** pada `index.html`.
- Ganti item **Portfolio / Experience / Training / Certifications** sesuai kebutuhan.
- Form kontak memakai `mailto:` → tidak perlu backend. Bisa diganti Formspree/EmailJS kalau mau form submit tanpa membuka email client.
